﻿namespace PacmanGame
{
    using System;
    using System.Threading;
    public class PacMan
    {
        // Класа за ПакМенчето - просто пази позицията му
        public PacMan(int posX, int posY)
        {
            this.XPos = posX;
            this.YPos = posY;
        }

        public int XPos
        {
            get;
            set;
        }

        public int YPos
        {
            get;
            set;
        }
    }
}