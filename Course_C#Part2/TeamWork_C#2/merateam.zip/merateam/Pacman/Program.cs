﻿namespace PacmanGame
{
    using System;
    using System.Threading;

    class Program
    {
        // Константите и глобалните променливи
        public const int WindowsHeight = 23;
        public const int WindowsWidth = 40;
        public const int MazeHeight = 27;
        public const int MazeWidth = 21;
        private static int score = 0;
        private static int goldCount = 0;
        private static Random rand = new Random();
        private static Ghosts[] ghosts = new Ghosts[3];
        private static PacMan[] pacMan = new PacMan[1];
        private static string[,] maze = new string[MazeWidth, MazeHeight];

        static void Main()
        {
            Console.SetWindowSize(WindowsWidth, WindowsHeight);
                                 
            GenerateMaze(maze);
            GenerateGold(maze);
            GeneratePacMan(maze);
            GenerateGhosts(maze);           
            do
            {
                DrawAll(maze);
                ScoreBoard();
                MovePacMan(maze);
                MoveGhosts(maze);
                Thread.Sleep(500);
                if (goldCount == score)
                {
                    DrawAll(maze);
                    Console.WriteLine("You won!");
                    break;
                }
            } 
            while (true);
        }

        static void MovePacMan(string[,] maze)
        {
            /* Метода за движение на ПакМен-а. Първо вземаме текущото му положение
             * След това в зависимост от натисната стрелка проверяваме в тази
             * посока дали има стена. Ако има - не правим нищо. Но ако няма се прави
             * проверка дали има А)Злато Б)Дух. Ако има злато се вдига резултата с 1
             * Ако има Дух - GameOver :)
             * */
            int row = pacMan[0].XPos;
            int col = pacMan[0].YPos;
            if (Console.KeyAvailable)
            {             
                ConsoleKeyInfo keyPressed = Console.ReadKey(true);
                while (Console.KeyAvailable)
                {
                    Console.ReadKey(true);    
                }

                if (keyPressed.Key == ConsoleKey.UpArrow)
                {
                    if ((maze[row - 1, col] != "│") &&
                        (maze[row - 1, col] != "─") &&
                        (maze[row - 1, col] != "┌") &&
                        (maze[row - 1, col] != "┐") &&
                        (maze[row - 1, col] != "└") &&
                        (maze[row - 1, col] != "┘"))
                    {
                        if (maze[row - 1, col] == "*")
                        {
                            score++;    
                        }

                        if (maze[row - 1, col] == "☻")
                        {
                            DrawAll(maze);
                            Console.WriteLine("Game over!");
                            Environment.Exit(0);
                        }

                        maze[row - 1, col] = "☺";
                        maze[row, col] = " ";
                        pacMan[0].XPos = row - 1;
                        pacMan[0].YPos = col;                      
                    }
                }

                if (keyPressed.Key == ConsoleKey.LeftArrow)
                {
                    if ((maze[row, col - 1] != "│") &&
                        (maze[row, col - 1] != "─") &&
                        (maze[row, col - 1] != "┌") &&
                        (maze[row, col - 1] != "┐") &&
                        (maze[row, col - 1] != "└") &&
                        (maze[row, col - 1] != "┘"))
                    {
                        if (maze[row, col - 1] == "*")
                        {
                            score++;
                        }

                        if (maze[row, col - 1] == "☻")
                        {
                            DrawAll(maze);
                            Console.WriteLine("Game over!");
                            Environment.Exit(0);
                        }

                        maze[row, col - 1] = "☺";
                        maze[row, col] = " ";
                        pacMan[0].XPos = row;
                        pacMan[0].YPos = col - 1;
                    }
                }

                if (keyPressed.Key == ConsoleKey.DownArrow)
                {
                    if ((maze[row + 1, col] != "│") &&
                        (maze[row + 1, col] != "─") &&
                        (maze[row + 1, col] != "┌") &&
                        (maze[row + 1, col] != "┐") &&
                        (maze[row + 1, col] != "└") &&
                        (maze[row + 1, col] != "┘"))
                    {
                        if (maze[row + 1, col] == "*")
                        {
                            score++;
                        }

                        if (maze[row + 1, col] == "☻")
                        {
                            DrawAll(maze);
                            Console.WriteLine("Game over!");
                            Environment.Exit(0);
                        }

                        maze[row + 1, col] = "☺";
                        maze[row, col] = " ";
                        pacMan[0].XPos = row + 1;
                        pacMan[0].YPos = col;
                    }
                }

                if (keyPressed.Key == ConsoleKey.RightArrow)
                {
                    if ((maze[row, col + 1] != "│") &&
                        (maze[row, col + 1] != "─") &&
                        (maze[row, col + 1] != "┌") &&
                        (maze[row, col + 1] != "┐") &&
                        (maze[row, col + 1] != "└") &&
                        (maze[row, col + 1] != "┘"))
                    {
                        if (maze[row, col + 1] == "*")
                        {
                            score++;
                        }

                        if (maze[row, col + 1] == "☻")
                        {
                            DrawAll(maze);
                            Console.WriteLine("Game over!");
                            Environment.Exit(0);
                        }

                        maze[row, col + 1] = "☺";
                        maze[row, col] = " ";
                        pacMan[0].XPos = row;
                        pacMan[0].YPos = col + 1;
                    }
                }
            }
        }

        static void MoveGhosts(string[,] maze)
        {
            for (int i = 0; i < ghosts.Length; i++)
            {
                int position = rand.Next(4);
                int row = ghosts[i].XPos;
                int col = ghosts[i].YPos;

                switch (position)
                {
                    case 0 :
                        if ((maze[row, col + 1] != "│") &&
                        (maze[row, col + 1] != "─") &&
                        (maze[row, col + 1] != "┌") &&
                        (maze[row, col + 1] != "┐") &&
                        (maze[row, col + 1] != "└") &&
                        (maze[row, col + 1] != "┘"))
                        {
                            if (maze[row, col + 1] == "*")
                            {
                                maze[row, col + 1] = "☻";
                                maze[row, col] = "*";
                                ghosts[i].XPos = row;
                                ghosts[i].YPos = col + 1;
                            }
                            else if (maze[row, col + 1] == "☺")
                            {
                                DrawAll(maze);
                                Console.WriteLine("Game over!");
                                Environment.Exit(0);
                            }
                            else
                            {
                                maze[row, col + 1] = "☻";
                                maze[row, col] = " ";
                                ghosts[i].XPos = row;
                                ghosts[i].YPos = col + 1;
                            }
                        }
                        break;
                    case 1:
                        if ((maze[row, col - 1] != "│") &&
                        (maze[row, col - 1] != "─") &&
                        (maze[row, col - 1] != "┌") &&
                        (maze[row, col - 1] != "┐") &&
                        (maze[row, col - 1] != "└") &&
                        (maze[row, col - 1] != "┘"))
                        {
                            if (maze[row, col - 1] == "*")
                            {
                                maze[row, col - 1] = "☻";
                                maze[row, col] = "*";
                                ghosts[i].XPos = row;
                                ghosts[i].YPos = col - 1;
                            }
                            else if (maze[row, col - 1] == "☺")
                            {
                                DrawAll(maze);
                                Console.WriteLine("Game over!");
                                Environment.Exit(0);
                            }
                            else
                            {
                                maze[row, col - 1] = "☻";
                                maze[row, col] = " ";
                                ghosts[i].XPos = row;
                                ghosts[i].YPos = col - 1;
                            }
                        }
                        break;
                    case 2:
                        if ((maze[row + 1, col] != "│") &&
                        (maze[row + 1, col] != "─") &&
                        (maze[row + 1, col] != "┌") &&
                        (maze[row + 1, col] != "┐") &&
                        (maze[row + 1, col] != "└") &&
                        (maze[row + 1, col] != "┘"))
                        {
                            if (maze[row + 1, col] == "*")
                            {
                                maze[row + 1, col] = "☻";
                                maze[row, col] = "*";
                                ghosts[i].XPos = row + 1;
                                ghosts[i].YPos = col;
                            }
                            else if (maze[row + 1, col] == "☺")
                            {
                                DrawAll(maze);
                                Console.WriteLine("Game over!");
                                Environment.Exit(0);
                            }
                            else
                            {
                                maze[row + 1, col] = "☻";
                                maze[row, col] = " ";
                                ghosts[i].XPos = row + 1;
                                ghosts[i].YPos = col;
                            }
                        }
                        break;
                    case 3:
                        if ((maze[row - 1, col] != "│") &&
                        (maze[row - 1, col] != "─") &&
                        (maze[row - 1, col] != "┌") &&
                        (maze[row - 1, col] != "┐") &&
                        (maze[row - 1, col] != "└") &&
                        (maze[row - 1, col] != "┘"))
                        {
                            if (maze[row - 1, col] == "*")
                            {
                                maze[row - 1, col] = "☻";
                                maze[row, col] = "*";
                                ghosts[i].XPos = row - 1;
                                ghosts[i].YPos = col;
                            }
                            else if (maze[row - 1, col] == "☺")
                            {
                                DrawAll(maze);
                                Console.WriteLine("Game over!");
                                Environment.Exit(0);
                            }
                            else
                            {
                                maze[row - 1, col] = "☻";
                                maze[row, col] = " ";
                                ghosts[i].XPos = row - 1;
                                ghosts[i].YPos = col;
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        static void ScoreBoard()
        {
            Console.SetCursorPosition(WindowsWidth - 10, 0);
            Console.WriteLine("Score: {0}", score);
        }

        static void GenerateGhosts(string[,] maze)
        {
            /* Този метод генерира Духовете. Избрал съм да са 3, като слага едни 
             * рандъм row и col спрамо максималните стойности, ако на тази
             * позиция има празно място го слага там, като се създава нов обект 
             * от Класа Ghost и този обект е част от масива на духовете. Записваме
             * позицията на духа.
             * със съответния символ : ☻
             * */
            int count = 0;
            do
            {
                int row = rand.Next(maze.GetLength(0) - 1);
                int col = rand.Next(maze.GetLength(1) - 1);
                
                if (maze[row, col] == " ")
                {
                    ghosts[count] = new Ghosts(row, col);
                    maze[row, col] = "☻";
                    count++;
                    if (count == 3)
                    {
                        break;
                    }                
                }
            } 
            while (true);
        }

        static void GeneratePacMan(string[,] maze)
        {
            // Подобен метод но за Пакмен-а със символа му : ☺
            do
            {
                int row = rand.Next(maze.GetLength(0) - 1);
                int col = rand.Next(maze.GetLength(1) - 1);

                if (maze[row, col] == " ")
                {
                    pacMan[0] = new PacMan(row, col);
                    maze[row, col] = "☺";
                    break;
                }
            } 
            while (true);
        }

        static void GenerateGold(string[,] maze)
        {  
            /* Тук се генерира златото, прави се просто проверка дали полето е 
             * свободно, ако е слага символ * и вдига броя на златните кюлчета с 1
             * */
            for (int row = 0; row < maze.GetLength(0); row++)
            {
                for (int col = 0; col < maze.GetLength(1); col++)
                {
                    if (maze[row, col] == " ")
                    {
                        if (rand.Next(100) < 20)
                        {
                            maze[row, col] = "*";
                            goldCount++;
                        }                         
                    }                  
                }
            }
        }

        static void GenerateMaze(string[,] maze)
        {
            /* Тук се генерира самата форма, има 6 различни символа, като формата
             * на самото поле взех от друга такава игра, за да не мислим наша :)
             * 6-те символа са |, -, ┌, ┐, └, ┘
             * Размерите на самото поле са указани в константни променливи съоетветно
             * 27 на 25. Към момента позициите на вътрешните стени са указани с 
             * точни позиции, но ще е добре да бъдат сменени с относителни, спрямо 
             * големината на полето, така при промяна на големината ще се променят
             * адекватно и вътрешните стени.
             * */
            for (int row = 0; row < maze.GetLength(0); row++)
            {
                for (int col = 0; col < maze.GetLength(1); col++)
                {
                    if ((row == 0 & col == 0) || (row == 3 & col == 3))
                    {
                         maze[row, col] = "┌";        
                    }
                    else if ((row == 0 & col == maze.GetLength(1) - 1) || (row == 3 & col == 23))
                    {
                        maze[row, col] = "┐";
                    }
                    else if ((row == maze.GetLength(0) - 1 & col == 0) || (row == 17 & col == 3))
                    {
                        maze[row, col] = "└";
                    }
                    else if ((row == maze.GetLength(0) - 1 & col == maze.GetLength(1) - 1) || (row == 17 & col == 23))
                    {
                        maze[row, col] = "┘";
                    }
                    else if ((row == 0 || row == maze.GetLength(0) - 1) ||
                            (row == 3 && (col >= 3 && col <= 8)) ||
                            (row == 3 && (col >= 18 && col <= 23)) ||
                            (row == 17 && (col >= 3 && col <= 8)) ||
                            (row == 17 && (col >= 18 && col <= 23)) ||
                            (row == 10 && (col >= 11 && col <= 15)))
                    {
                        maze[row, col] = "─";    
                    }
                    else if ((col == 0 || col == maze.GetLength(1) - 1) ||
                            (col == 3 && (row >= 3 && row <= 7)) ||
                            (col == 3 && (row >= 13 && row <= 17)) ||
                            (col == 7 && (row >= 9 && row <= 11)) ||
                            (col == 12 && (row >= 4 && row <= 8)) ||
                            (col == 12 && (row >= 12 && row <= 16)) ||
                            (col == 14 && (row >= 4 && row <= 8)) ||
                            (col == 14 && (row >= 12 && row <= 16)) ||
                            (col == 19 && (row >= 9 && row <= 11)) ||
                            (col == 23 && (row >= 3 && row <= 7)) ||
                            (col == 23 && (row >= 13 && row <= 17)))
                    {
                        maze[row, col] = "│";
                    }
                    else
                    {
                        maze[row, col] = " ";
                    }
                }    
            }           
        }

        static void DrawAll(string[,] maze)
        {
            /* Това е метода за изрисуване на всичко, в зависимост от стойността
             * на позицията в матрицата цвета е различен - черен за духовете, жълт 
             * за златото и Pacman-а и т.н.
             * */
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Black;
            Console.ForegroundColor = ConsoleColor.White;
            for (int row = 0; row < maze.GetLength(0); row++)
            {
                for (int col = 0; col < maze.GetLength(1); col++)
                {
                    if (maze[row, col] == "*")
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;        
                    }
                    else if (maze[row, col] == "☻")
                    {
                        Console.ForegroundColor = ConsoleColor.Blue; 
                    }
                    else if (maze[row, col] == "☺")
                    {
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                    }

                    Console.Write(maze[row, col]);
                }

                Console.WriteLine();
            }
        }
    }
}
