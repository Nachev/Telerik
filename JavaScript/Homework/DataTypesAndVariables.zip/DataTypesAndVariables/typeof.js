/*jslint browser: true*/
/*global jsConsoleWriteLine, arrayLiteral, numberLiteral, booleanLiteral, floatLiteral, objectLiteral, stringLiteral*/

jsConsoleWriteLine("3.Try typeof on all variables you created.");
jsConsoleWriteLine(typeof arrayLiteral);
jsConsoleWriteLine(typeof numberLiteral);
jsConsoleWriteLine(typeof booleanLiteral);
jsConsoleWriteLine(typeof floatLiteral);
jsConsoleWriteLine(typeof objectLiteral);
jsConsoleWriteLine(typeof stringLiteral);
jsConsoleWriteLine();