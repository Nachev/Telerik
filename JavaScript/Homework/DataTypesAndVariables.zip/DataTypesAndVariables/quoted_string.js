/*jslint browser: true*/
/*global jsConsoleWriteLine*/
var quotedString = "'How you doin'?', Joey said.";
jsConsoleWriteLine("2.Create a string variable with quoted text in it. For example: 'How you doin'?', Joey said.");
jsConsoleWriteLine(quotedString);
jsConsoleWriteLine();