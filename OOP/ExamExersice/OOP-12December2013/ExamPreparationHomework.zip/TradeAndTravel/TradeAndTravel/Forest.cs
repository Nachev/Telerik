﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TradeAndTravel
{
    public class Forest : Location, IGatheringLocation
    {
        public Forest(string name) 
            : base(name, LocationType.Forest)
        {
        }

        public ItemType GatheredType
        {
            get { return ItemType.Wood; }
        }

        public ItemType RequiredItem
        {
            get { return ItemType.Wood; }
        }

        public Item ProduceItem(string name)
        {
            throw new NotImplementedException();
        }
    }
}
