﻿namespace AnimalWorld
{
    public interface ISound
    {
        string ProduceSound();
    }
}
