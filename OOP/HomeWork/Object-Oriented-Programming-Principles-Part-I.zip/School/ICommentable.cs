﻿namespace School
{
    internal interface ICommentable
    {
        string Comment { get; set; }
    }
}
