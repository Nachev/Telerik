﻿namespace Bank
{
    public interface IDepositable
    {
        void Deposit(decimal sum);
    }
}
