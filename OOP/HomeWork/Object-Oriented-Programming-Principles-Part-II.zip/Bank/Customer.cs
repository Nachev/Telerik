﻿namespace Bank
{
    public enum Customer
    {
        Individual,
        Company,
    }
}
