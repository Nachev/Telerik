﻿using System;
using System.Linq;

namespace Infestation
{
    public class WeaponrySkill : Supplement
    {
        public override void ReactTo(ISupplement otherSupplement)
        {
        }
    }
}
