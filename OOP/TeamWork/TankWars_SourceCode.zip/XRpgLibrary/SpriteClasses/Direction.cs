﻿namespace XTankWarsLibrary.SpriteClasses
{
    public enum Direction
    {
        Up, Down, Left, Right
    }
}
