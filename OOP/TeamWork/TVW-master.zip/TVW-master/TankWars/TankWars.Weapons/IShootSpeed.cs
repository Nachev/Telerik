﻿namespace TankWars.Weapons
{
    public interface IShootSpeed
    {
        int ShootSpeed { get; }
    }
}
