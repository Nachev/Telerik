﻿namespace TankWars.Units
{
    using System;
    public class Class1
    {
    }
}
