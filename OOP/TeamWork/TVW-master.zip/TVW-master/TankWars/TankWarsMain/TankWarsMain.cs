﻿namespace TankWars
{
    using System;

    class TankWarsMain
    {
        static void Main()
        {
        }
    }
}
