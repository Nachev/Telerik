﻿namespace TankWars.Player
{
    using System;
    public interface IPlayer
    {
        string Name { get; }
    }
}
