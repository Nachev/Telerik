﻿namespace TankWars.Tanks
{
    public enum TankModeEnum
    {
        Defence,
        Attack
    }
}
