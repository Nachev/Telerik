namespace AbstractFactory
{
    /// <summary>
    /// The 'ProductA2' class
    /// </summary>
    public class Bison : Herbivore
    {
    }
}