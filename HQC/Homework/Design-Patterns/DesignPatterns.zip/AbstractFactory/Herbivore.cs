namespace AbstractFactory
{
    /// <summary>
    /// The 'AbstractProductA' abstract class
    /// </summary>
    public abstract class Herbivore
    {
    }
}