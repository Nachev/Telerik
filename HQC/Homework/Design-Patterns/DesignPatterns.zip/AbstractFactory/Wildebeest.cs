namespace AbstractFactory
{
    /// <summary>
    /// The 'ProductA1' class
    /// </summary>
    public class Wildebeest : Herbivore
    {
    }
}