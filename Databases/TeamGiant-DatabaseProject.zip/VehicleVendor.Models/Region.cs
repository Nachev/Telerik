﻿namespace VehicleVendor.Models
{
    public enum Region
    {
        Americas = 1,
        Europe = 2,
        AsiaAndOceania = 3,
        MiddleEastAndAfrica = 4
    }
}
