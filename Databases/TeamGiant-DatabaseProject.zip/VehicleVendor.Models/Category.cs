﻿namespace VehicleVendor.Models
{
    public enum Category
    {
        Car = 1,
        Minivan = 2,
        SUV = 3,
        Crossover = 4,
        Truck = 5
    }
}
