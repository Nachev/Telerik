﻿namespace VehicleVendor.Reports
{
    public interface IReportGenerator
    {
        void GenerateReport();
    }
}
