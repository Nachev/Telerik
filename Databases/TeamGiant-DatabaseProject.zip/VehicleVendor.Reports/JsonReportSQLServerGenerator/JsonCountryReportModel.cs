﻿namespace VehicleVendor.Reports.JsonReportSQLServerGenerator
{
    using VehicleVendor.Models;

    public class JsonCountryReportModel
    {
        public string Country { get; set; }

        public Region Region { get; set; }
    }
}
