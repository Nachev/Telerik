﻿namespace VehicleVendor.Reports.JsonReportSQLServerGenerator
{
    public class JsonDealerReportModel
    {
        public string Company { get; set; }

        public int CountryId { get; set; }

        public string Address { get; set; }
    }
}