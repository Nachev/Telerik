/// <remarks/>

namespace VehicleVendor.Reports.XmlReportSqlServerGenerator.Classes
{
    using System;
    using System.CodeDom.Compiler;
    using System.ComponentModel;
    using System.Diagnostics;
    using System.Xml.Serialization;

    [GeneratedCodeAttribute("xsd", "4.0.30319.33440")]
    [SerializableAttribute()]
    [DebuggerStepThroughAttribute()]
    [DesignerCategoryAttribute("code")]
    [XmlTypeAttribute(Namespace = "http://nissan.com/ReportSchema.xsd")]
    public partial class XmlDaySaleReportModel
    {
        private DateTime dateField;

        private decimal valueField;

        /// <remarks/>
        [XmlAttributeAttribute("date", DataType = "date")]
        public DateTime Date
        {
            get
            {
                return this.dateField;
            }
            set
            {
                this.dateField = value;
            }
        }

        /// <remarks/>
        [XmlTextAttribute()]
        public decimal Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }
}