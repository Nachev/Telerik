DatabaseTeamProject
===================

Team project using SQL, MySQL, MongoDB and SQLite databases, C# and Entity Framework with Code First
